./statik -m -src="./Linux/web/dist" -f -dest="./Linux/server/embed" -p web -ns web
mkdir ./controller

export GOOS=linux
export GOARCH=arm
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_arm Linux/server
export GOARCH=arm64
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_arm64 Linux/server
export GOARCH=386
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_i386 Linux/server
export GOARCH=amd64
go build -ldflags "-s -w" -tags=jsoniter -o ./controller/server_linux_amd64 Linux/server

