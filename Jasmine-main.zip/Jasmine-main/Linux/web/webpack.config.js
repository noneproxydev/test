const path = require("path");
const esbuild = require('esbuild');
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const {ESBuildMinifyPlugin} = require("esbuild-loader");
const {CleanWebpackPlugin} = require("clean-webpack-plugin");
const AntdDayjsWebpackPlugin = require("antd-dayjs-webpack-plugin");
const CompressionPlugin = require("compression-webpack-plugin");
const { update } = require("lodash");

module.exports = (env, args) => {
    let mode = args.mode;
    return {
        entry: path.join(__dirname, 'src/index.jsx'),
        output: {
            publicPath: mode === 'development' ? undefined : './',
            path: path.resolve(__dirname, 'dist'),
            filename: '[name].[contenthash:7].js'
        },
        devtool: mode === 'development' ? 'eval-source-map' : false,
        module: {
            rules: [
                {
                    test: /\.(js|jsx)$/i,
                    loader: 'esbuild-loader',
                    include: path.resolve(__dirname, 'src'),
                    options: {
                        loader: 'jsx',
                        target: 'es2015'
                    }
                },
                {
                    test: /\.css$/,
                    use: [
                        'style-loader',
                        'css-loader',
                        {
                            loader: 'esbuild-loader',
                            options: {
                                loader: 'css',
                                minify: true
                            }
                        }
                    ]
                },
                {
                    test: /\.less$/,
                    use: [
                        'style-loader',
                        'css-loader',
                        {
                            loader: 'less-loader',
                            options: {
                                lessOptions: {
                                    javascriptEnabled: true
                                }
                            }
                        }
                    ]
                }
            ]
        },
        resolve: {
            extensions: [
                '.js',
                '.jsx'
            ]
        },
        plugins: [
            new HtmlWebpackPlugin({
                appMountId: 'root',
                template:  path.resolve(__dirname, 'public/index.html'),
                filename: 'index.html',
                inject: true
            }),